# Keep the native bridge's method signatures stable so libludoengine.so's
# JNI-exported symbols (Java_com_ultimateodul_ludo_NativeBridge_...) keep
# matching after R8/ProGuard minification.
-keepclasseswithmembernames class com.ultimateodul.ludo.NativeBridge {
    native <methods>;
}
-keep class com.ultimateodul.ludo.MoveOutcome { *; }
