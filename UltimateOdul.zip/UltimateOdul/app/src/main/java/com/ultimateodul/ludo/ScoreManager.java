package com.ultimateodul.ludo;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Persists win/loss stats for Ultimate Odul.
 * <p>
 * Written in Java (rather than Kotlin) to demonstrate that the project mixes
 * both JVM languages freely — this class and NativeBridge.kt are called
 * interchangeably from MainActivity.kt.
 */
public final class ScoreManager {

    private static final String PREFS_NAME = "ultimate_odul_prefs";
    private static final String KEY_WINS_PREFIX = "wins_player_";
    private static final String KEY_GAMES_PLAYED = "games_played";

    private final SharedPreferences prefs;

    public ScoreManager(Context context) {
        this.prefs = context.getApplicationContext()
                .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public void recordWin(int playerIndex) {
        String key = KEY_WINS_PREFIX + playerIndex;
        int current = prefs.getInt(key, 0);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt(key, current + 1);
        editor.putInt(KEY_GAMES_PLAYED, prefs.getInt(KEY_GAMES_PLAYED, 0) + 1);
        editor.apply();
    }

    public int getWins(int playerIndex) {
        return prefs.getInt(KEY_WINS_PREFIX + playerIndex, 0);
    }

    public int getGamesPlayed() {
        return prefs.getInt(KEY_GAMES_PLAYED, 0);
    }

    public void resetStats() {
        prefs.edit().clear().apply();
    }
}
