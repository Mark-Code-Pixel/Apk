package com.ultimateodul.ludo

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.animation.OvershootInterpolator
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {

    private lateinit var engine: NativeBridge
    private lateinit var scoreManager: ScoreManager
    private lateinit var boardView: LudoBoardView

    private lateinit var statusText: TextView
    private lateinit var subStatusText: TextView
    private lateinit var diceButton: TextView

    private val playerNames = arrayOf("You", "Coral", "Sable", "Indigo")
    private val playerCore = intArrayOf(
        Color.parseColor("#FF3B5C"),
        Color.parseColor("#22E08B"),
        Color.parseColor("#FFD23F"),
        Color.parseColor("#3FA9FF")
    )
    private val diceFaces = arrayOf("🎲", "⚀", "⚁", "⚂", "⚃", "⚄", "⚅")

    private val humanPlayer = 0
    private var currentPlayer = 0
    private var lastRoll = 0
    private var awaitingHumanPawnChoice = false
    private var rolling = false

    private val avatarRings = arrayOfNulls<View>(4)
    private val avatarDots = arrayOfNulls<View>(4)
    private val avatarLabels = arrayOfNulls<TextView>(4)
    private val pulseAnimators = arrayOfNulls<ObjectAnimator>(4)

    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        engine = NativeBridge().also { it.start() }
        scoreManager = ScoreManager(this)

        boardView = findViewById(R.id.boardView)
        statusText = findViewById(R.id.statusText)
        subStatusText = findViewById(R.id.subStatusText)
        diceButton = findViewById(R.id.diceButton)

        bindAvatarStrip()
        boardView.onPawnTapped = { player, pawn -> onPawnTapped(player, pawn) }

        diceButton.setOnClickListener { onDiceTapped() }
        findViewById<View>(R.id.titleText).setOnLongClickListener {
            confirmNewGame()
            true
        }

        refreshBoard(animate = false)
        setActivePlayer(currentPlayer)
    }

    override fun onDestroy() {
        super.onDestroy()
        engine.destroy()
    }

    // ---------------------------------------------------------------- HUD

    private fun bindAvatarStrip() {
        val ids = intArrayOf(R.id.avatar0, R.id.avatar1, R.id.avatar2, R.id.avatar3)
        for (i in 0 until 4) {
            val chip = findViewById<View>(ids[i])
            avatarRings[i] = chip.findViewById(R.id.avatarRing)
            avatarDots[i] = chip.findViewById(R.id.avatarDot)
            avatarLabels[i] = chip.findViewById(R.id.avatarLabel)
            avatarDots[i]?.background?.setTint(playerCore[i])
            avatarLabels[i]?.text = playerNames[i]
        }
    }

    private fun setActivePlayer(player: Int) {
        currentPlayer = player
        boardView.currentPlayer = player
        for (i in 0 until 4) {
            pulseAnimators[i]?.cancel()
            avatarRings[i]?.setBackgroundResource(if (i == player) R.drawable.bg_avatar_active else R.drawable.bg_avatar_idle)
            avatarRings[i]?.scaleX = 1f
            avatarRings[i]?.scaleY = 1f
            if (i == player) {
                val pulse = ObjectAnimator.ofFloat(avatarRings[i], "scaleX", 1f, 1.18f, 1f)
                pulse.duration = 900
                pulse.repeatCount = ValueAnimator.INFINITE
                val pulseY = ObjectAnimator.ofFloat(avatarRings[i], "scaleY", 1f, 1.18f, 1f)
                pulseY.duration = 900
                pulseY.repeatCount = ValueAnimator.INFINITE
                pulse.start(); pulseY.start()
                pulseAnimators[i] = pulse
            }
        }

        if (player == humanPlayer) {
            statusText.text = getString(R.string.your_turn)
            subStatusText.text = getString(R.string.tap_dice_to_roll)
            diceButton.isEnabled = true
            diceButton.alpha = 1f
        } else {
            statusText.text = getString(R.string.ai_thinking, playerNames[player])
            subStatusText.text = ""
            diceButton.isEnabled = false
            diceButton.alpha = 0.4f
            mainHandler.postDelayed({ takeAiTurn(player) }, 700)
        }
    }

    private fun refreshBoard(animate: Boolean = true) {
        boardView.updateBoardState(engine.getBoardState(), animate)
    }

    // ---------------------------------------------------------------- Dice

    private fun onDiceTapped() {
        if (currentPlayer != humanPlayer || rolling || awaitingHumanPawnChoice) return
        performRoll(humanPlayer)
    }

    private fun performRoll(player: Int) {
        rolling = true
        val spin = ObjectAnimator.ofFloat(diceButton, "rotation", 0f, 360f * 2)
        spin.duration = 500
        spin.interpolator = OvershootInterpolator()
        spin.start()

        var ticks = 0
        val flicker = object : Runnable {
            override fun run() {
                diceButton.text = diceFaces[(1..6).random()]
                ticks++
                if (ticks < 6) mainHandler.postDelayed(this, 60)
            }
        }
        mainHandler.post(flicker)

        mainHandler.postDelayed({
            val roll = engine.rollDice()
            lastRoll = roll
            diceButton.text = if (roll in 1..6) diceFaces[roll] else "💥"
            rolling = false
            handleRollResult(player, roll)
        }, 430)
    }

    private fun handleRollResult(player: Int, roll: Int) {
        if (roll == 0) {
            // three 6s in a row — turn forfeited
            toast("Three 6s! Turn forfeited.")
            advanceTurn(extra = false)
            return
        }

        val validMoves = engine.getValidMoves(player, roll)
        if (validMoves.isEmpty()) {
            if (player == humanPlayer) {
                subStatusText.text = "No legal moves — passing turn"
            }
            mainHandler.postDelayed({ advanceTurn(extra = false) }, 500)
            return
        }

        if (player == humanPlayer) {
            statusText.text = getString(R.string.rolled_value, roll)
            subStatusText.text = getString(R.string.pick_a_pawn)
            boardView.highlightedMoves = validMoves.toSet()
            boardView.invalidate()
            awaitingHumanPawnChoice = true
        } else {
            val chosenPawn = engine.aiChooseMove(player, roll)
            mainHandler.postDelayed({ applyMove(player, chosenPawn, roll) }, 450)
        }
    }

    // ---------------------------------------------------------------- Moves

    private fun onPawnTapped(player: Int, pawn: Int) {
        if (!awaitingHumanPawnChoice || player != humanPlayer || player != currentPlayer) return
        if (!boardView.highlightedMoves.contains(pawn)) return
        awaitingHumanPawnChoice = false
        boardView.highlightedMoves = emptySet()
        applyMove(player, pawn, lastRoll)
    }

    private fun applyMove(player: Int, pawn: Int, roll: Int) {
        if (pawn < 0) {
            advanceTurn(extra = false)
            return
        }
        val outcome = engine.movePawn(player, pawn, roll)
        refreshBoard(animate = true)

        mainHandler.postDelayed({
            if (outcome.captured) {
                toast(getString(R.string.captured_toast, playerNames[player]))
            }
            if (outcome.playerWon) {
                onPlayerWon(player)
                return@postDelayed
            }
            if (outcome.extraTurn) {
                if (player == humanPlayer) {
                    subStatusText.text = getString(R.string.six_extra_turn)
                }
                setActivePlayer(player) // same player goes again
            } else {
                advanceTurn(extra = false)
            }
        }, 460)
    }

    private fun advanceTurn(extra: Boolean) {
        if (extra) {
            setActivePlayer(currentPlayer)
            return
        }
        val next = (currentPlayer + 1) % 4
        setActivePlayer(next)
    }

    private fun takeAiTurn(player: Int) {
        if (player != currentPlayer) return
        performRoll(player)
    }

    // ---------------------------------------------------------------- Win

    private fun onPlayerWon(player: Int) {
        scoreManager.recordWin(player)
        val label = if (player == humanPlayer) "You" else playerNames[player]
        AlertDialog.Builder(this)
            .setTitle("🏆")
            .setMessage(getString(R.string.player_wins, label) + "\n\n" + getString(R.string.games_played_fmt, scoreManager.getGamesPlayed()))
            .setPositiveButton(R.string.new_game) { _, _ -> startNewGame() }
            .setCancelable(false)
            .show()
    }

    private fun confirmNewGame() {
        AlertDialog.Builder(this)
            .setTitle("New game?")
            .setMessage("This will reset the current board.")
            .setPositiveButton("Reset") { _, _ -> startNewGame() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun startNewGame() {
        engine.resetGame()
        awaitingHumanPawnChoice = false
        boardView.highlightedMoves = emptySet()
        refreshBoard(animate = false)
        setActivePlayer(0)
    }

    private fun toast(message: String) {
        Snackbar.make(boardView, message, Snackbar.LENGTH_SHORT).show()
    }
}
