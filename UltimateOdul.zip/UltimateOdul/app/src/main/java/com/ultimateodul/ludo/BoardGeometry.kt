package com.ultimateodul.ludo

/**
 * Pure geometry — no Android types — so it's easy to unit test.
 * Mirrors the step numbering used by the native engine (ludo_logic.h):
 * step -1 = yard, 0..50 = shared 52-cell outer track, 51..56 = home column
 * (56 = finished / centre triangle).
 */
object BoardGeometry {

    const val GRID = 15

    /** The 52 shared track cells, in board order, as (row, col). Index == global track step. */
    val trackCells: Array<IntArray> = buildTrackCells()

    /** Player index -> that player's 6 home-column cells (step 51..56), ordered toward the centre. */
    val homeColumns: Array<Array<IntArray>> = arrayOf(
        arrayOf(intArrayOf(7, 1), intArrayOf(7, 2), intArrayOf(7, 3), intArrayOf(7, 4), intArrayOf(7, 5), intArrayOf(7, 6)),
        arrayOf(intArrayOf(1, 7), intArrayOf(2, 7), intArrayOf(3, 7), intArrayOf(4, 7), intArrayOf(5, 7), intArrayOf(6, 7)),
        arrayOf(intArrayOf(7, 13), intArrayOf(7, 12), intArrayOf(7, 11), intArrayOf(7, 10), intArrayOf(7, 9), intArrayOf(7, 8)),
        arrayOf(intArrayOf(13, 7), intArrayOf(12, 7), intArrayOf(11, 7), intArrayOf(10, 7), intArrayOf(9, 7), intArrayOf(8, 7))
    )

    /** Player index -> top-left (row, col) of that player's 6x6 yard block. */
    val yardOrigin: Array<IntArray> = arrayOf(
        intArrayOf(0, 0),   // red: top-left
        intArrayOf(0, 9),   // green: top-right
        intArrayOf(9, 9),   // yellow: bottom-right
        intArrayOf(9, 0)    // blue: bottom-left
    )

    /** The 4 pawn-slot offsets inside a 6x6 yard block. */
    val yardSlotOffsets: Array<IntArray> = arrayOf(
        intArrayOf(1, 1), intArrayOf(1, 3), intArrayOf(3, 1), intArrayOf(3, 3)
    )

    const val CENTER_ROW = 7
    const val CENTER_COL = 7

    /** Start offset (global track index) for each player, matching kStartOffset in ludo_logic.h. */
    val startOffset = intArrayOf(0, 13, 26, 39)

    /** Global track indices that are safe (star) cells, matching kSafeCells in ludo_logic.h. */
    val safeCells = setOf(0, 8, 13, 21, 26, 34, 39, 47)

    /**
     * Resolves a player's pawn `step` (-1..56) to a board cell.
     * Returns null for a pawn still in the yard (draw it in its yard slot instead).
     */
    fun cellForStep(player: Int, step: Int): IntArray? {
        return when {
            step < 0 -> null
            step <= 50 -> {
                val globalIndex = (startOffset[player] + step) % 52
                trackCells[globalIndex]
            }
            step in 51..55 -> homeColumns[player][step - 51]
            else -> intArrayOf(CENTER_ROW, CENTER_COL) // finished
        }
    }

    private fun buildTrackCells(): Array<IntArray> {
        val cells = mutableListOf<IntArray>()
        fun add(row: Int, col: Int) = cells.add(intArrayOf(row, col))

        for (c in 1..5) add(6, c)
        for (r in 5 downTo 0) add(r, 6)
        add(0, 7)
        for (r in 0..5) add(r, 8)
        for (c in 9..14) add(6, c)
        add(7, 14)
        for (c in 14 downTo 9) add(8, c)
        for (r in 9..14) add(r, 8)
        add(14, 7)
        for (r in 14 downTo 9) add(r, 6)
        for (c in 5 downTo 0) add(8, c)
        add(7, 0)
        add(6, 0)

        require(cells.size == 52) { "Track must have exactly 52 cells, built ${cells.size}" }
        return cells.toTypedArray()
    }
}
