#include "ludo_logic.h"
#include "dice_native.h"

namespace ultimateodul {

LudoEngine::LudoEngine() {
    resetGame();
}

void LudoEngine::resetGame() {
    for (auto &playerPawns : board_) {
        playerPawns.fill(kYard);
    }
    consecutiveSixes_ = 0;
    dice_seed(0);
}

int LudoEngine::rollDice() {
    int value = dice_roll();
    if (value == 6) {
        consecutiveSixes_++;
        if (consecutiveSixes_ >= 3) {
            // Advanced rule: three 6s in a row burns the turn.
            consecutiveSixes_ = 0;
            return 0;
        }
    } else {
        consecutiveSixes_ = 0;
    }
    return value;
}

int LudoEngine::globalCell(int player, int step) {
    if (step < 0 || step > kMainPathLength - 1) {
        return -1; // in yard, or already inside the private home column
    }
    return (kStartOffset[player] + step) % 52;
}

bool LudoEngine::isSafeCell(int globalCellIndex) {
    for (int safe : kSafeCells) {
        if (safe == globalCellIndex) return true;
    }
    return false;
}

std::vector<int> LudoEngine::getValidMoves(int player, int diceValue) const {
    std::vector<int> moves;
    if (diceValue < 1 || diceValue > 6) return moves;

    for (int p = 0; p < kPawnsPerPlayer; p++) {
        int step = board_[player][p];

        if (step == kFinishStep) continue; // already home, done

        if (step == kYard) {
            if (diceValue == 6) moves.push_back(p); // need a 6 to leave the yard
            continue;
        }

        int newStep = step + diceValue;
        if (newStep > kFinishStep) continue; // overshoots the finish, illegal
        moves.push_back(p);
    }
    return moves;
}

MoveResult LudoEngine::movePawn(int player, int pawn, int diceValue) {
    MoveResult result;
    int step = board_[player][pawn];

    bool leavingYard = (step == kYard && diceValue == 6);
    int newStep = leavingYard ? 0 : step + diceValue;

    bool isValid = (leavingYard) ||
                    (step != kYard && step != kFinishStep && newStep <= kFinishStep);
    if (!isValid) {
        return result; // result.legal stays false
    }

    result.legal = true;
    board_[player][pawn] = newStep;
    result.newStep = newStep;

    if (newStep == kFinishStep) {
        result.pawnFinished = true;
        result.extraTurn = true;
    }

    // Capture check: only applies on the shared outer track, not the home column.
    int landedGlobalCell = globalCell(player, newStep);
    if (landedGlobalCell != -1 && !isSafeCell(landedGlobalCell)) {
        for (int otherPlayer = 0; otherPlayer < kNumPlayers; otherPlayer++) {
            if (otherPlayer == player) continue;
            for (int otherPawn = 0; otherPawn < kPawnsPerPlayer; otherPawn++) {
                int otherStep = board_[otherPlayer][otherPawn];
                if (otherStep == kYard || otherStep == kFinishStep) continue;
                if (globalCell(otherPlayer, otherStep) == landedGlobalCell) {
                    board_[otherPlayer][otherPawn] = kYard; // sent back to base
                    result.captured = true;
                    result.capturedPlayer = otherPlayer;
                    result.capturedPawn = otherPawn;
                    result.extraTurn = true;
                }
            }
        }
    }

    if (diceValue == 6) {
        result.extraTurn = true;
    }

    if (checkWin(player)) {
        result.playerWon = true;
    }

    return result;
}

bool LudoEngine::checkWin(int player) const {
    for (int p = 0; p < kPawnsPerPlayer; p++) {
        if (board_[player][p] != kFinishStep) return false;
    }
    return true;
}

int LudoEngine::aiChooseMove(int player, int diceValue) const {
    std::vector<int> valid = getValidMoves(player, diceValue);
    if (valid.empty()) return -1;

    // 1) Prefer a move that captures an opponent.
    for (int pawn : valid) {
        int step = board_[player][pawn];
        int newStep = (step == kYard) ? 0 : step + diceValue;
        int landed = globalCell(player, newStep);
        if (landed != -1 && !isSafeCell(landed)) {
            for (int op = 0; op < kNumPlayers; op++) {
                if (op == player) continue;
                for (int opw = 0; opw < kPawnsPerPlayer; opw++) {
                    int otherStep = board_[op][opw];
                    if (otherStep == kYard || otherStep == kFinishStep) continue;
                    if (globalCell(op, otherStep) == landed) return pawn;
                }
            }
        }
    }

    // 2) Prefer finishing a pawn.
    for (int pawn : valid) {
        int step = board_[player][pawn];
        if (step != kYard && step + diceValue == kFinishStep) return pawn;
    }

    // 3) Prefer leaving the yard to get another pawn into play.
    for (int pawn : valid) {
        if (board_[player][pawn] == kYard) return pawn;
    }

    // 4) Otherwise advance whichever pawn is furthest along (closest to home).
    int best = valid[0];
    for (int pawn : valid) {
        if (board_[player][pawn] > board_[player][best]) best = pawn;
    }
    return best;
}

} // namespace ultimateodul
