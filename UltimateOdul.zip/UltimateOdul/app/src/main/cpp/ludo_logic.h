#ifndef ULTIMATE_ODUL_LUDO_LOGIC_H
#define ULTIMATE_ODUL_LUDO_LOGIC_H

#include <array>
#include <vector>
#include <cstdint>

// This header uses plain `int` for game-rule values (board positions,
// dice faces 1-6, player/pawn indices 0-3) because those are always
// small, well within int32_t range on every Android ABI we target
// (armeabi-v7a, arm64-v8a, x86, x86_64) - `int` is 32-bit on all of
// them, so there is no 32-bit/64-bit divergence here. The dice module
// (dice_native.h) uses explicit int32_t/uint32_t at the C boundary for
// the same reason belt-and-suspenders style.

namespace ultimateodul {

constexpr int kNumPlayers = 4;
constexpr int kPawnsPerPlayer = 4;
constexpr int kMainPathLength = 51;   // steps 0..50 walk the shared outer track
constexpr int kHomeEntry = 51;        // step index where a pawn turns into its home column
constexpr int kFinishStep = 56;       // pawn has reached the centre / is "home"
constexpr int kYard = -1;             // pawn hasn't left its base yet

// Global board cell (0..51) where each color's track begins.
constexpr std::array<int, kNumPlayers> kStartOffset = {0, 13, 26, 39};

// Global cells that are "safe" (star squares + each color's own start cell).
// A pawn sitting on one of these can never be captured.
constexpr std::array<int, 8> kSafeCells = {0, 8, 13, 21, 26, 34, 39, 47};

struct MoveResult {
    bool legal = false;
    int newStep = kYard;
    bool captured = false;      // did this move send an opponent pawn home?
    int capturedPlayer = -1;
    int capturedPawn = -1;
    bool extraTurn = false;     // rolled a 6, or captured, or reached finish
    bool pawnFinished = false;
    bool playerWon = false;     // all 4 pawns finished
};

class LudoEngine {
public:
    LudoEngine();

    void resetGame();

    // Rolls the die via the C dice module. Also tracks the "three 6s in a
    // row forfeits the turn" advanced rule and returns 0 in that case.
    int rollDice();

    // Which of the given player's pawns can legally move with this roll.
    std::vector<int> getValidMoves(int player, int diceValue) const;

    // Executes the move. Caller should have validated with getValidMoves.
    MoveResult movePawn(int player, int pawn, int diceValue);

    bool checkWin(int player) const;

    // Simple heuristic AI: capture > finish a pawn > leave the yard >
    // advance the pawn furthest along > any legal move.
    int aiChooseMove(int player, int diceValue) const;

    int getPawnStep(int player, int pawn) const { return board_[player][pawn]; }
    void setPawnStep(int player, int pawn, int step) { board_[player][pawn] = step; }

private:
    // board_[player][pawn] = step along that player's personal path,
    // kYard if still at base, kFinishStep if home.
    std::array<std::array<int, kPawnsPerPlayer>, kNumPlayers> board_{};
    int consecutiveSixes_ = 0;

    static int globalCell(int player, int step); // -1 if step is in the home column
    static bool isSafeCell(int globalCellIndex);
};

} // namespace ultimateodul

#endif // ULTIMATE_ODUL_LUDO_LOGIC_H
