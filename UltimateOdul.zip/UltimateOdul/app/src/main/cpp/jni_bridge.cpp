#include <jni.h>
#include <cstdint>
#include <vector>
#include "ludo_logic.h"

using ultimateodul::LudoEngine;

// A native engine pointer is handed to Kotlin as a jlong "handle".
// jlong is always 64-bit in the JVM spec, but a pointer is only 32-bit
// on armeabi-v7a/x86. Casting through uintptr_t (not directly through
// jlong) is what keeps this correct on BOTH bit-widths: widening a
// 32-bit pointer into a 64-bit jlong is safe, and truncating back down
// with reinterpret_cast<uintptr_t> on the way in is exact because we
// only ever round-trip a value we handed out ourselves.
static inline jlong toHandle(LudoEngine *engine) {
    return static_cast<jlong>(reinterpret_cast<uintptr_t>(engine));
}

static inline LudoEngine *fromHandle(jlong handle) {
    return reinterpret_cast<LudoEngine *>(static_cast<uintptr_t>(handle));
}

extern "C" {

JNIEXPORT jlong JNICALL
Java_com_ultimateodul_ludo_NativeBridge_nativeInit(JNIEnv *, jobject) {
    return toHandle(new LudoEngine());
}

JNIEXPORT void JNICALL
Java_com_ultimateodul_ludo_NativeBridge_nativeDestroy(JNIEnv *, jobject, jlong handle) {
    delete fromHandle(handle);
}

JNIEXPORT void JNICALL
Java_com_ultimateodul_ludo_NativeBridge_nativeResetGame(JNIEnv *, jobject, jlong handle) {
    fromHandle(handle)->resetGame();
}

JNIEXPORT jint JNICALL
Java_com_ultimateodul_ludo_NativeBridge_nativeRollDice(JNIEnv *, jobject, jlong handle) {
    return fromHandle(handle)->rollDice();
}

JNIEXPORT jintArray JNICALL
Java_com_ultimateodul_ludo_NativeBridge_nativeGetValidMoves(
        JNIEnv *env, jobject, jlong handle, jint player, jint diceValue) {
    std::vector<int> moves = fromHandle(handle)->getValidMoves(player, diceValue);
    jintArray result = env->NewIntArray(static_cast<jsize>(moves.size()));
    if (!moves.empty()) {
        env->SetIntArrayRegion(result, 0, static_cast<jsize>(moves.size()), moves.data());
    }
    return result;
}

// Returns [legal, newStep, captured, capturedPlayer, capturedPawn, extraTurn,
//          pawnFinished, playerWon] packed as ints (0/1 for booleans).
JNIEXPORT jintArray JNICALL
Java_com_ultimateodul_ludo_NativeBridge_nativeMovePawn(
        JNIEnv *env, jobject, jlong handle, jint player, jint pawn, jint diceValue) {
    ultimateodul::MoveResult r = fromHandle(handle)->movePawn(player, pawn, diceValue);
    jint packed[8] = {
            r.legal ? 1 : 0,
            r.newStep,
            r.captured ? 1 : 0,
            r.capturedPlayer,
            r.capturedPawn,
            r.extraTurn ? 1 : 0,
            r.pawnFinished ? 1 : 0,
            r.playerWon ? 1 : 0
    };
    jintArray result = env->NewIntArray(8);
    env->SetIntArrayRegion(result, 0, 8, packed);
    return result;
}

JNIEXPORT jboolean JNICALL
Java_com_ultimateodul_ludo_NativeBridge_nativeCheckWin(JNIEnv *, jobject, jlong handle, jint player) {
    return fromHandle(handle)->checkWin(player) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jint JNICALL
Java_com_ultimateodul_ludo_NativeBridge_nativeAiChooseMove(
        JNIEnv *, jobject, jlong handle, jint player, jint diceValue) {
    return fromHandle(handle)->aiChooseMove(player, diceValue);
}

// Returns all 16 pawn steps flattened: player 0 pawns 0-3, player 1 pawns 0-3, ...
JNIEXPORT jintArray JNICALL
Java_com_ultimateodul_ludo_NativeBridge_nativeGetBoardState(JNIEnv *env, jobject, jlong handle) {
    LudoEngine *engine = fromHandle(handle);
    jint flat[ultimateodul::kNumPlayers * ultimateodul::kPawnsPerPlayer];
    int idx = 0;
    for (int p = 0; p < ultimateodul::kNumPlayers; p++) {
        for (int w = 0; w < ultimateodul::kPawnsPerPlayer; w++) {
            flat[idx++] = engine->getPawnStep(p, w);
        }
    }
    jintArray result = env->NewIntArray(idx);
    env->SetIntArrayRegion(result, 0, idx, flat);
    return result;
}

} // extern "C"
