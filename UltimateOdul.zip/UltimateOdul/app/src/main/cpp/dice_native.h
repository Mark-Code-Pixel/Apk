#ifndef ULTIMATE_ODUL_DICE_NATIVE_H
#define ULTIMATE_ODUL_DICE_NATIVE_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Fixed-width types are used throughout (uint32_t / int32_t) instead of
 * bare int/unsigned int so the module behaves identically whether it is
 * compiled for a 32-bit ABI (armeabi-v7a, x86) or a 64-bit ABI
 * (arm64-v8a, x86_64). None of this code relies on pointer size or
 * `long`, so it is portable across both without any #ifdefs.
 */

/* Seed the xorshift32 generator. Call once at engine init. */
void dice_seed(uint32_t seed);

/* Roll a fair six-sided die. Returns 1-6. */
int32_t dice_roll(void);

#ifdef __cplusplus
}
#endif

#endif /* ULTIMATE_ODUL_DICE_NATIVE_H */
