# Ultimate Odul

A native-powered, premium-styled Ludo game for Android.

## Architecture — genuinely multi-language

| Layer | Language | File(s) | Role |
|---|---|---|---|
| RNG core | **C** | `app/src/main/cpp/dice_native.c` / `.h` | xorshift32 dice roll, seeded independently |
| Rules engine + AI | **C++17** | `app/src/main/cpp/ludo_logic.cpp` / `.h` | movement, capture, win detection, heuristic AI |
| JNI glue | **C++** | `app/src/main/cpp/jni_bridge.cpp` | exposes the engine to the JVM as `libludoengine.so` |
| Native bridge | **Kotlin** | `NativeBridge.kt` | `System.loadLibrary`, `external fun` declarations |
| Board geometry | **Kotlin** | `BoardGeometry.kt` | maps engine step numbers -> 15x15 grid cells |
| Rendering | **Kotlin** | `LudoBoardView.kt` | custom `View`: gradients, glow, animated pawns |
| Game orchestration | **Kotlin** | `MainActivity.kt` | turn loop, dice animation, AI pacing, win dialog |
| Stats persistence | **Java** | `ScoreManager.java` | SharedPreferences win/loss tracking |

All C/C, C++, and Java/Kotlin pieces are wired together and compiled by
Gradle + CMake into one `.so` per ABI, loaded at runtime.

## 32-bit and 64-bit support

`app/build.gradle` builds and packages **all four** common Android ABIs into
one APK:

- 32-bit: `armeabi-v7a`, `x86`
- 64-bit: `arm64-v8a`, `x86_64`

`abi { enable false }` under `splits` keeps them bundled together rather
than split into separate per-ABI APKs, so a single install works everywhere.
None of the C/C++ source uses pointer-size-dependent tricks except the JNI
handle cast in `jni_bridge.cpp`, which deliberately round-trips the engine
pointer through `uintptr_t` (not directly through `jlong`) — that's what
makes the cast correct on both 32-bit and 64-bit targets.

## Gameplay

- Standard 4-player, 4-pawn-each Ludo rules: roll a 6 to leave the yard,
  captures send opponents back to base, 8 star/safe cells are capture-proof,
  rolling a 6 / capturing / finishing a pawn grants an extra turn, three 6s
  in a row forfeits the turn.
- You play the red seat; the other three seats are controlled by an
  in-engine heuristic AI (prioritizes captures, then finishing a pawn, then
  leaving the yard, then advancing its furthest pawn).
- Win/loss record is saved locally across sessions.

## Visual style

Dark glass-panel HUD, neon per-player gradients, glowing gold star cells,
glossy radial-gradient pawns with drop shadows, spring-eased animated pawn
slides (not instant jumps), a spinning/flickering dice roll animation, and
a pulsing gold ring around whichever seat is currently active.

## Building

1. Open the `UltimateOdul/` folder in Android Studio (Iguana or newer).
2. Let Gradle sync — it will invoke CMake automatically via the NDK to
   build `libludoengine.so` for all four ABIs.
3. Run on a device or emulator (minSdk 23).

Requires the Android NDK + CMake components installed via
**Tools -> SDK Manager -> SDK Tools** if Android Studio doesn't prompt for
them automatically.

## Project layout

```
UltimateOdul/
├── build.gradle / settings.gradle / gradle.properties
└── app/
    ├── build.gradle
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── cpp/
        │   ├── CMakeLists.txt
        │   ├── dice_native.c / dice_native.h      (C)
        │   ├── ludo_logic.cpp / ludo_logic.h       (C++)
        │   └── jni_bridge.cpp                      (C++ / JNI)
        ├── java/com/ultimateodul/ludo/
        │   ├── NativeBridge.kt
        │   ├── BoardGeometry.kt
        │   ├── LudoBoardView.kt
        │   ├── MainActivity.kt
        │   └── ScoreManager.java                   (Java)
        └── res/...
```
